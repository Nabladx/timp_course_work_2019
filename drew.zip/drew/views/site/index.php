<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
$this->title = 'Аукцион';
?>
<div class="site-index">
    <div class="body-content">
        <div class="row">
                <script src="/web/js/script.js"></script>
                <nav class="dws-menu">
                    <ul>
                            <li><a href="http://drew/site/lots">Инфо</a></li>
                            <li><a href="http://drew/site/lot">Добавить</a></li>
                    </ul>
                </nav>
        </div>
        <div class="jumbotron">
            <p class="lead1">Добро пожаловать в систему аукциона.</p>
            <p class="lead2">
                Данный аукцион представляет собой публичную продажу товаров.
                Вы можете предлагать свои товары, составляя лоты или
                принять участия в торгах. Пользователь, чья цена
                будет наивысшей за лот на момент окончания торгов,
                становится новым владельцем лота.
                Вы можете посмотреть информацию по всем выставленным лотам
                и принять участие в торгах при помощи вкладки "ИНФО".
                Чтобы добавить свой лот, нажмите вкладку "ДОБАВИТЬ".
            </p>
        </div>
    </div>


</div>
