<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<div class="change_price">
    <?php $form = ActiveForm::begin(); ?>
        <?= $form->field($model, 'Цена') ?>
        <div class="form-group">
            <?= Html::submitButton('Предложить', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div>
