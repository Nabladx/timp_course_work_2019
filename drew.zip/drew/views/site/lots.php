<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Lot */
/* @var $form ActiveForm */
?>
<h4>Информация по лотам.</h4>
<div>
    <style>
        table {
            width: 100%; /* Ширина таблицы */
            background: white; /* Цвет фона таблицы */
            /*color: white; !* Цвет текста *!*/
            border-spacing: 0px; /* Расстояние между ячейками */
            text-align : center;
        }
        td, th {
            /*background: maroon; !* Цвет фона ячеек *!*/
            padding: 2px; /* Поля вокруг текста */
            outline: 1.5px solid #000;
            text-align : center;
        }
        </style>
    <table>
        <tr><th>Номер лота</th><th>Название</th><th>Описание</th><th>Окочательная дата</th><th>Цена(руб.)</th><th>Покупатель</th></tr>
        <?foreach ($lots as $usr) :?>
            <tr>
                <td><?=$usr->id?></td>
                <td><?=$usr->Название?></td>
                <td><?=$usr->Описание?></td>
                <td><?=$usr->Дедлайн?></td>
                <td><?=$usr->Цена?></td>
                <td><?=$usr->Покупатель?></td>
                <td><div class="suggestion" ><button><a href="http://drew/site/change_price">Увеличить цену на</a></button></div></td></tr>
        <?endforeach;?>
    </table>
</div>
