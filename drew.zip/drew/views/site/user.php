<div>
    <?foreach ($user as $usr) :?>
      <?=$usr->username?>
    <?endforeach;?>
</div>