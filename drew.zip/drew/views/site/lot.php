<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $model app\models\Lot */
/* @var $form ActiveForm */
?>
<div class="lot">
    <?php $form = ActiveForm::begin(); ?>
        <?= $form->field($model, 'Название') ?>
        <?= $form->field($model, 'Описание') ?>
        <?= $form->field($model, 'Дедлайн') ?>
        <?= $form->field($model, 'Цена') ?>
        <h5><b>Предполагаемый</b></h5>
        <?= $form->field($model, 'Покупатель') ?>
        <div class="form-group">
            <?= Html::submitButton('Добавить', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div><!-- lot -->
