<?php

namespace app\models;

use Yii;
use yii\web\IdentityInterface;
/**
 * This is the model class for table "lots".
 *
 * @property int $id
 * @property string $Название
 * @property string $Описание
 * @property string $Дата завершения приёма ставок
 * @property int $Начальная цена (руб.)
 * @property int $Шаг ставки (руб.)
 */
class Lots extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'lots';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Название', 'Описание', 'Дата завершения приёма ставок', 'Начальная цена (руб.)', 'Шаг ставки (руб.)'], 'required'],
            [['Дата завершения приёма ставок'], 'safe'],
            [['Начальная цена (руб.)', 'Шаг ставки (руб.)'], 'integer'],
            [['Название', 'Описание'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Название' => 'Название',
            'Описание' => 'Описание',
            'Дата завершения приёма ставок' => 'Дата Завершения Приёма Ставок',
            'Начальная цена (руб.)' => 'Начальная Цена (руб )',
            'Шаг ставки (руб.)' => 'Шаг Ставки (руб )',
        ];
    }
}
