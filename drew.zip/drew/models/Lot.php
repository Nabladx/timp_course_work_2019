<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "lot".
 *
 * @property int $id
 * @property string $Название
 * @property string $Описание
 * @property string $Дедлайн
 * @property int $Цена
 * @property string $Покупатель
 */
class Lot extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'lot';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [[ 'Цена'], 'required'],

            [['Цена'], 'integer'],
            [['Название', 'Описание', 'Покупатель'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Название' => 'Название',
            'Описание' => 'Описание',
            'Дедлайн' => 'Дедлайн',
            'Цена' => 'Цена',
            'Покупатель' => 'Покупатель',
        ];
    }
}
