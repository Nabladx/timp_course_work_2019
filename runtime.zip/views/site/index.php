
<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
$this->title = 'Аукцион';
?>
<?php
if($_SESSION['index'] != 'b') {
    $_SESSION['index'] = 'b';
    header("Location: http://drew/site/login");
    exit;
}
?>


    <div class="site-index">
        <div class="body-content">


                <div class="row">
                    <script src="/web/js/script.js"></script>
                    <nav class="dws-menu">
                        <ul>
                            <li><a href="http://drew/site/lots"><b>Инфо</b></a></li>
                            <li><a href="http://drew/site/lot"><b>Добавить</b></a></li>
                        </ul>
                    </nav>
                </div>
            <!--        <div class="jumbotron">-->

                <p class="lead2">
                    Добро пожаловать в систему аукциона!<br>
                    Данный аукцион представляет собой публичную продажу товаров.<br>
                    Вы можете предлагать свои товары, выставляя лоты или принять участия в торгах.<br>
                    Пользователь, чья цена будет наивысшей за лот на момент окончания торгов,<br>
                    становится новым владельцем лота.<br>
                    Вы можете посмотреть информацию по всем выставленным лотам<br>
                    и принять участие в торгах при помощи вкладки "ИНФО".<br>
                    Чтобы добавить свой лот, нажмите вкладку "ДОБАВИТЬ".
                </p>
            <!--        </div>-->

        </div>

</div>
