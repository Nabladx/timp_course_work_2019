<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Lot */
/* @var $form ActiveForm */
?>
<h3>Информация по лотам.</h3>
<?php
$i = 0;
$k = 0;
foreach ($lots as $usr) {
    $i++;
    if($usr->Дедлайн < date("Y-m-d"))
    {
        $usr->delete();
        header("Refresh: 0");
        exit;
    }
    if ($usr->Дедлайн == date("Y-m-d")) {
        if($usr->Покупатель != null){
            if($usr->Покупатель == Yii::$app->user->identity->username) {
                echo "<h2>Поздравляем Вас с приобретением  <font color=red><b>$i</b></font>-о  лота! Свяжитесь с пользователем <font color=red><b>$usr->Владелец</b></font>.</h2>";
            }
        }
        if($usr->Покупатель != null) {
            if ($usr->Владелец == Yii::$app->user->identity->username) {
                echo "<h2>Поздравляем, Ваш лот номер <font color=red><b>$i</b></font> купил <font color=red><b>$usr->Покупатель</b></font>.</h2>";
            }
        }
        if($usr->Покупатель == null) {
            if ($usr->Владелец == Yii::$app->user->identity->username) {
                echo "<h2>К сожалению Ваш лот номер <font color=red><b>$i</b></font> никто не купил. Подождите пока лот удалится из списка.</h2>";
            }
        }
        $k = 1;
    }
}
echo "<table><tr><th>Номер лота</th><th>Владелец</th><th>Название</th><th>Описание</th><th>Окончательная дата</th><th>Цена(руб.)</th><th>Покупатель</th><th>Предложить цену по лоту</th></tr>";
$i = 0;
foreach ($lots as $usr)
{
    $i++;
    if(($usr->Владелец != Yii::$app->user->identity->username)&&($usr->Дедлайн != date("Y-m-d")))
    {
        echo "<table>
                                <tr>
                                <td>$i</td>
                                <td>$usr->Владелец</td>
                                <td>$usr->Название</td>
                                <td>$usr->Описание</td>  
                                <td>$usr->Дедлайн</td>
                                <td>$usr->Цена</td>
                                <td>$usr->Покупатель</td>
                                <td><button class=\"offer\" id=\"$usr->id\" onclick=\"offer(this.id)\">⚫</button></td>
                                </tr>
                          </table>";
    }
    else
    {
        echo "<table>
                                <tr>
                                <td>$i</td>
                                <td>$usr->Владелец</td>
                                <td>$usr->Название</td>
                                <td>$usr->Описание</td>  
                                <td>$usr->Дедлайн</td>
                                <td>$usr->Цена</td>
                                <td>$usr->Покупатель</td>
                                <td></td>
                                </tr>
                          </table>";
    }
}
?>

<div>
    <script src="/web/js/script.js"></script>
    <style>
        table {
            width: 100%; /* Ширина таблицы */
            background: #222222;
            color: white; /* Цвет текста */
            /*border-radius: 10px;*/
            /*-webkit-border-radius: 10px;*/
            /*-moz-border-radius: 10px;*/
            /*-khtml-border-radius: 10px;*/
            border-spacing: 0px; /* Расстояние между ячейками */
            text-align : center;
            table-layout: fixed;
            word-wrap: break-word;
        }
        td, th {
            background: #222222; /* Цвет фона ячеек *!*!*/
            /*border-radius: 10px;*/
            /*-webkit-border-radius: 10px;*/
            /*-moz-border-radius: 10px;*/
            /*-khtml-border-radius: 10px;*/
            padding: 5px; /* Поля вокруг текста */
            outline: 1px solid gray; /* Сетка таблицы */
            text-align : center;
        }
        </style>
<!--    <table>-->
<!--        <tr><th>Номер лота</th><th>Владелец</th><th>Название</th><th>Описание</th><th>Окончательная дата</th><th>Цена(руб.)</th><th>Покупатель</th><th>Предложить цену по лоту</th></tr>-->
<!--        --><?//foreach ($lots as $usr) :?>
<!--            <tr>-->
<!--                <td>--><?//=$usr->id?><!--</td>-->
<!--                <td>--><?//=$usr->Владелец?><!--</td>-->
<!--                <td>--><?//=$usr->Название?><!--</td>-->
<!--                <td>--><?//=$usr->Описание?><!--</td>-->
<!--                <td>--><?//=$usr->Дедлайн?><!--</td>-->
<!--                <td>--><?//=$usr->Цена?><!--</td>-->
<!--                <td>--><?//=$usr->Покупатель?><!--</td>-->
<!--                <td><button class="offer" id="--><?//=$usr->id?><!--" onclick="offer(this.id)">⚫</button></td></tr>-->
<!--        --><?//endforeach;?>
<!--    </table>-->
        <?php

        ?>
</div>
