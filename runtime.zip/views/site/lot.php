<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
/* @var $this yii\web\View */
/* @var $model app\models\Lot */
/* @var $form ActiveForm */
?>
<div class="lot">
    <?php $form = ActiveForm::begin(); ?>
        <?= $form->field($model, 'Название') ?>
        <?= $form->field($model, 'Описание') ?>
        <?= $form->field($model, 'Дедлайн')->widget(DatePicker::className(), [
            'name' => 'check_issue_date',
            //'value' => date('Y-m-d', strtotime('+2 days')),
            'options' => ['placeholder' => 'Необходимо выбрать хотя бы следующую дату'],
            'pluginOptions' => [
                'format' => 'yyyy-m-d',
                'todayHighlight' => true,
                'startDate' => '+1d'
                ],
        ])?>
        <?= $form->field($model, 'Цена') ?>
<!--       --><?//= $form->field($model, 'Покупатель') ?>
        <div class="form-group">
            <?= Html::submitButton('Добавить', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div><!-- lot -->
