<?php

use app\models\Lot;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>
<?php

   if ($_GET['ip']) {
        $ip = (int)$_GET['ip'];
        $username = Yii::$app->user->identity->username;
        $id = $ip;
        $model = Lot::findOne($id);
        echo "<h4>Введите новую цену для выбранного лота (<b>$model->Название</b>)</h4>";
        if ($model->load(Yii::$app->request->post())) {
            if ($model->Цена < $model->Новая_цена) {
                $model->Цена = $model->Новая_цена;
                $model->Покупатель = $username;
                $model->save();
                Yii::$app->session->setFlash('success', 'Ваша цена принята!');
                header("Location: http://drew/site/lots");
                exit;
            } else {
                Yii::$app->session->setFlash('error', 'Ваша цена не принята, введите цену больше старой');
                echo "Старая цена:<font color=red> <b> $model->Цена  </b></font> руб.<br>";
                echo " <br>";
            }
        }
}
?>
<div class="change_price">
    <?php $form = ActiveForm::begin(); ?>
        <?= $form->field($model, 'Новая_цена') ?>
        <div class="form-group">
            <?= Html::submitButton('Предложить', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div>
