<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "lot".
 *
 * @property int $id
 * @property string $Владелец
 * @property string $Название
 * @property string $Описание
 * @property string $Дедлайн
 * @property int $Цена
 * @property string $Покупатель
 * @property int $Новая_цена
 */
class Lot extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'lot';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Название', 'Цена', 'Дедлайн'], 'required'],
            [['Дедлайн'], 'safe'],
            [['Цена', 'Новая_цена'], 'integer', 'min' => 1, 'max' => 1000000000],
            [['Владелец', 'Название', 'Описание', 'Покупатель'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Владелец' => 'Владелец',
            'Название' => 'Название',
            'Описание' => 'Описание',
            'Дедлайн' => 'Дедлайн',
            'Цена' => 'Цена',
            'Покупатель' => 'Покупатель',
            'Новая_цена' => 'Новая Цена',
        ];
    }
}
