function add_lot() {
// родительский элемент UL
const add_lot = document.getElementById('add');
// элемент для вставки перед ним (первый LI)
const first_lot = add_lot.getElementsByTagName('LI')[0];

// новый элемент
const new_lot = document.createElement('LI');
new_lot.innerHTML = 'Новый лот'

// вставка
add_lot.insertBefore(new_lot, first_lot)
}

function view_lots() {
        var el = document.getElementById('all_lots');
        if (el.firstChild.data == "⚫")
        {
            el.firstChild.data = "⚪";
        }
        else
        {
            el.firstChild.data = "⚫";
        }
        if (document.getElementById('text').hidden == true) {
            document.getElementById('text').hidden = false;
        }
        else
        {
            document.getElementById('text').hidden = true;
        }
}

function offer(clicked_id) {
        let ip = clicked_id;
        location.href = "http://drew/site/change_price?ip=" + ip;
        //document.location.href='http://drew/site/change_price';
}
function offer1(clicked_id) {
    let ij = clicked_id;
    location.href = "http://drew/site/change_price?ij=" + ij;
    //document.location.href='http://drew/site/change_price';
}
